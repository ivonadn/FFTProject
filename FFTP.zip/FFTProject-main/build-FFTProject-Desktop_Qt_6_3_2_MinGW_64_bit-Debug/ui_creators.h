/********************************************************************************
** Form generated from reading UI file 'creators.ui'
**
** Created by: Qt User Interface Compiler version 6.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CREATORS_H
#define UI_CREATORS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_creators
{
public:
    QWidget *centralwidget;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *creators)
    {
        if (creators->objectName().isEmpty())
            creators->setObjectName(QString::fromUtf8("creators"));
        creators->resize(924, 600);
        centralwidget = new QWidget(creators);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(360, 10, 201, 91));
        QFont font;
        font.setFamilies({QString::fromUtf8("Times New Roman")});
        font.setPointSize(15);
        font.setBold(true);
        font.setItalic(true);
        label->setFont(font);
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(40, 150, 121, 31));
        QFont font1;
        font1.setFamilies({QString::fromUtf8("Times New Roman")});
        font1.setPointSize(11);
        font1.setBold(true);
        font1.setItalic(true);
        label_2->setFont(font1);
        label_3 = new QLabel(centralwidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(680, 150, 121, 31));
        label_3->setFont(font1);
        label_4 = new QLabel(centralwidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(10, 180, 361, 261));
        label_5 = new QLabel(centralwidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(540, 190, 361, 261));
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(10, 510, 101, 41));
        pushButton_2 = new QPushButton(centralwidget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(820, 510, 101, 41));
        creators->setCentralWidget(centralwidget);
        menubar = new QMenuBar(creators);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 924, 21));
        creators->setMenuBar(menubar);
        statusbar = new QStatusBar(creators);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        creators->setStatusBar(statusbar);

        retranslateUi(creators);

        QMetaObject::connectSlotsByName(creators);
    } // setupUi

    void retranslateUi(QMainWindow *creators)
    {
        creators->setWindowTitle(QCoreApplication::translate("creators", "MainWindow", nullptr));
        label->setText(QCoreApplication::translate("creators", "Creators of the project:", nullptr));
        label_2->setText(QCoreApplication::translate("creators", "Ivona Nencheva", nullptr));
        label_3->setText(QCoreApplication::translate("creators", "Sami Fetyani", nullptr));
        label_4->setText(QString());
        label_5->setText(QString());
        pushButton->setText(QCoreApplication::translate("creators", "Exit", nullptr));
        pushButton_2->setText(QCoreApplication::translate("creators", "Continue", nullptr));
    } // retranslateUi

};

namespace Ui {
    class creators: public Ui_creators {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CREATORS_H
