#include "creators.h"
#include "ui_creators.h"
#include <QPixmap>
#include "mainwindow.h"

creators::creators(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::creators)
{
    ui->setupUi(this);
    QPixmap bkgnd("C:/Users/Sami.Fetiani/Desktop/uni/FFTProject-main/FFTProject/background.jpg");
    bkgnd = bkgnd.scaled(this->size(), Qt::IgnoreAspectRatio);
    QPalette palette;
    palette.setBrush(QPalette::Window, bkgnd);
    this->setPalette(palette);

    ui->label->setStyleSheet("QLabel { color : white; }");
    ui->label_2->setStyleSheet("QLabel { color : white; }");
    ui->label_3->setStyleSheet("QLabel { color : white; }");
    QPixmap pixmap("C:/Users/Sami.Fetiani/Desktop/uni/FFTProject-main/FFTProject/ivona.jpg");
    ui->label_4->setPixmap(pixmap);
    ui->label_4->setScaledContents(true);


    QPixmap pixmap2("C:/Users/Sami.Fetiani/Desktop/uni/FFTProject-main/FFTProject/hoodrabbit.jpg");
    ui->label_5->setPixmap(pixmap2);
    ui->label_5->setScaledContents(true);
}

creators::~creators()
{
    delete ui;
}

void creators::on_pushButton_clicked()
{
     this->close();
}


void creators::on_pushButton_2_clicked()
{
     MainWindow *mainWin = new MainWindow;
     mainWin->show();
     this->close();
}

