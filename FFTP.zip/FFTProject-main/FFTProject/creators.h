#ifndef CREATORS_H
#define CREATORS_H

#include <QMainWindow>

namespace Ui {
class creators;
}

class creators : public QMainWindow
{
    Q_OBJECT

public:
    explicit creators(QWidget *parent = nullptr);
    ~creators();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::creators *ui;
};

#endif // CREATORS_H
