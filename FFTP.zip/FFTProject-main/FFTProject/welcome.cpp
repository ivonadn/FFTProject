#include "welcome.h"
#include "ui_welcome.h"
#include "mainwindow.h"
#include "creators.h"

welcome::welcome(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::welcome)
{
    ui->setupUi(this);
    QPixmap bkgnd("C:/Users/Sami.Fetiani/Desktop/uni/FFTProject-main/FFTProject/background.jpg");
    bkgnd = bkgnd.scaled(this->size(), Qt::IgnoreAspectRatio);
    QPalette palette;
    palette.setBrush(QPalette::Window, bkgnd);
    this->setPalette(palette);
    ui->label->setStyleSheet("QLabel { color : white; }");
}

welcome::~welcome()
{
    delete ui;
}

void welcome::on_pushButton_3_clicked()
{
    this->close();
}


void welcome::on_pushButton_clicked()
{
    MainWindow *mainWin = new MainWindow;
    mainWin->show();
    this->close();
}


void welcome::on_pushButton_2_clicked()
{
    creators *mainWin = new creators;
    mainWin->show();
    this->close();
}

